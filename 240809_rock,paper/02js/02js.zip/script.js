// Math 수학객체   => 함수
let num = 2.1234;
let num01 = 2.8765;

let maxNum = Math.max(10, 5, 8, 30);
let minNum = Math.min(10, 5, 8, 30);
let roundNum = Math.round(num);
let floorNum = Math.floor(num);
let ceilNum = Math.ceil(num);
let rndnum = Math.random();
let piNum = Math.PI;

document.write(maxNum, "<br/>");
document.write(minNum, "<br/>");
document.write(roundNum, "<br />");
document.write(floorNum, "<br />");
document.write(ceilNum, "<br />");
document.write(rndnum, "<br />");
document.write(piNum, "<br />");
