import React from "react";

const New = () => {
  return <div>New</div>;
};

export default New;
