import React from "react";
import { useNavigate } from "react-router-dom";
import styled from "styled-components";
import { getEmotionImgById } from "../util";

const Wrapper = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 15px 0;
  border-bottom: 1px solid #e2e2e2;
`;
const ImgBg = styled.div`
  width: 120px;
`;

const DiaryContent = styled.div``;

const Img = styled.img``;

const DiaryItem = ({ id, date, content, emotionId }) => {
  return (
    <Wrapper>
      <DiaryContent>
        <ImgBg>
          <Img
            src={getEmotionImgById(emotionId)}
            alt={`emotions${emotionId}`}
          />
        </ImgBg>
      </DiaryContent>
    </Wrapper>
  );
};

export default DiaryItem;
