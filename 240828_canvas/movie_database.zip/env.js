const API_KEY = "aaa894e6eb0e3ce17de554fab6e207a6";

export default { API_KEY };
