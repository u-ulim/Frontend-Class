import api from "./env.js";

const URL = `https://api.themoviedb.org/3/movie/popular?api_key=${api.API_KEY}&language=ko&page=1`;

fetch(URL)
  .then((response) => response.json())
  .then((results) => console.log(results));

