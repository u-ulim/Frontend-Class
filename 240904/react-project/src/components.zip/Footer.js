import React from "react";

const Footer = () => {
  return <div>여기는 푸터입니다+_+</div>;
};

export default Footer;
