import React from "react";

const Header = () => {
  return (
    <div>
      <h1>여기는 헤더입니다!</h1>
    </div>
  );
};

export default Header;
